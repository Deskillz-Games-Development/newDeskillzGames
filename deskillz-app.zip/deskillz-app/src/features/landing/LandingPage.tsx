import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { 
  Gamepad2, 
  Trophy, 
  Wallet, 
  Users, 
  Zap, 
  Shield,
  ChevronRight,
  Play,
  Star,
  TrendingUp
} from 'lucide-react'
import Button from '@/components/ui/Button'
import { Card, CardContent } from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import ParticleField from '@/components/effects/ParticleField'
import { formatCurrency, formatNumber } from '@/lib/utils'

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

// Mock data
const stats = [
  { label: 'Active Players', value: 25000, icon: Users },
  { label: 'Prize Pool', value: 1250000, prefix: '$', icon: Trophy },
  { label: 'Games', value: 48, icon: Gamepad2 },
  { label: 'Tournaments Daily', value: 150, icon: Zap },
]

const featuredGames = [
  {
    id: '1',
    name: 'Speed Racer X',
    genre: 'Racing',
    players: 1250,
    prizePool: 5000,
    image: 'https://images.unsplash.com/photo-1511882150382-421056c89033?w=400&h=300&fit=crop',
    rating: 4.8,
  },
  {
    id: '2',
    name: 'Puzzle Master',
    genre: 'Puzzle',
    players: 890,
    prizePool: 3500,
    image: 'https://images.unsplash.com/photo-1553481187-be93c21490a9?w=400&h=300&fit=crop',
    rating: 4.9,
  },
  {
    id: '3',
    name: 'Battle Arena',
    genre: 'Action',
    players: 2100,
    prizePool: 8000,
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=300&fit=crop',
    rating: 4.7,
  },
  {
    id: '4',
    name: 'Card Legends',
    genre: 'Strategy',
    players: 650,
    prizePool: 2500,
    image: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=400&h=300&fit=crop',
    rating: 4.6,
  },
]

const liveTournaments = [
  {
    id: '1',
    game: 'Speed Racer X',
    name: 'Grand Prix Finals',
    prizePool: 2500,
    players: 45,
    maxPlayers: 50,
    endsIn: '2h 15m',
    status: 'live',
  },
  {
    id: '2',
    game: 'Battle Arena',
    name: 'Weekend Warrior Cup',
    prizePool: 1000,
    players: 28,
    maxPlayers: 32,
    endsIn: '45m',
    status: 'live',
  },
  {
    id: '3',
    game: 'Puzzle Master',
    name: 'Speed Challenge',
    prizePool: 500,
    players: 12,
    maxPlayers: 20,
    endsIn: '3h 30m',
    status: 'registering',
  },
]

const features = [
  {
    icon: Shield,
    title: 'Secure & Fair',
    description: 'Blockchain-verified scores and automated prize distribution ensure fair play.',
  },
  {
    icon: Zap,
    title: 'Instant Payouts',
    description: 'Win and withdraw immediately to your Web3 wallet. No waiting periods.',
  },
  {
    icon: Users,
    title: 'Skill-Based Matching',
    description: 'AI-powered matchmaking pairs you with players of similar skill levels.',
  },
]

export default function LandingPage() {
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Particle effect */}
        <ParticleField particleCount={30} />
        
        {/* Hero content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Badge */}
            <Badge variant="info" size="lg" className="mb-6" glow>
              <Zap className="w-4 h-4" />
              Web3 Competitive Gaming
            </Badge>
            
            {/* Main heading */}
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              <span className="text-white">COMPETE.</span>
              <br />
              <span className="text-gradient">WIN.</span>
              <br />
              <span className="text-white">GET PAID.</span>
            </h1>
            
            {/* Subheading */}
            <p className="text-xl sm:text-2xl text-white/60 max-w-2xl mx-auto mb-10 font-body">
              Join thousands of players competing in skill-based tournaments. 
              <span className="text-neon-cyan"> Win real USDT prizes</span> and prove you're the best.
            </p>
            
            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                rightIcon={<ChevronRight className="w-5 h-5" />}
              >
                Start Playing
              </Button>
              <Button
                variant="secondary"
                size="lg"
                leftIcon={<Play className="w-5 h-5" />}
              >
                Watch Demo
              </Button>
            </div>
          </motion.div>
          
          {/* Floating stats cards */}
          <motion.div
            className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                variants={fadeInUp}
                className="group"
              >
                <div className="relative p-6 rounded-xl bg-gaming-light/30 border border-gaming-border/50 
                  hover:border-neon-cyan/50 transition-all duration-300
                  hover:shadow-[0_0_30px_rgba(0,240,255,0.1)]">
                  <stat.icon className="w-8 h-8 text-neon-cyan mb-3 mx-auto opacity-50 group-hover:opacity-100 transition-opacity" />
                  <div className="font-display text-3xl sm:text-4xl font-bold text-white mb-1">
                    {stat.prefix}
                    {formatNumber(stat.value)}
                  </div>
                  <div className="text-sm text-white/50 uppercase tracking-wider">
                    {stat.label}
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
        
        {/* Bottom gradient fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gaming-dark to-transparent" />
      </section>

      {/* Featured Games Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-10"
          >
            <div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-2">
                Featured Games
              </h2>
              <p className="text-white/50">Top-rated games with active tournaments</p>
            </div>
            <Link to="/games">
              <Button variant="ghost" rightIcon={<ChevronRight className="w-4 h-4" />}>
                View All
              </Button>
            </Link>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredGames.map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={`/games/${game.id}`}>
                  <Card className="group cursor-pointer h-full">
                    {/* Image */}
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={game.image}
                        alt={game.name}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-gaming-dark via-transparent to-transparent" />
                      
                      {/* Rating badge */}
                      <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 bg-gaming-dark/80 rounded-full">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        <span className="text-xs font-semibold text-white">{game.rating}</span>
                      </div>
                      
                      {/* Genre badge */}
                      <Badge variant="info" size="sm" className="absolute top-3 left-3">
                        {game.genre}
                      </Badge>
                    </div>
                    
                    <CardContent className="p-4">
                      <h3 className="font-display text-lg font-semibold text-white mb-3 group-hover:text-neon-cyan transition-colors">
                        {game.name}
                      </h3>
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-1 text-white/50">
                          <Users className="w-4 h-4" />
                          <span>{formatNumber(game.players)} playing</span>
                        </div>
                        <div className="flex items-center gap-1 text-neon-green">
                          <Trophy className="w-4 h-4" />
                          <span>{formatCurrency(game.prizePool)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Tournaments Section */}
      <section className="relative py-20 bg-gaming-darker/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-between mb-10"
          >
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-white">
                  Live Tournaments
                </h2>
                <Badge variant="danger" pulse>LIVE</Badge>
              </div>
              <p className="text-white/50">Jump into action right now</p>
            </div>
            <Link to="/tournaments">
              <Button variant="ghost" rightIcon={<ChevronRight className="w-4 h-4" />}>
                View All
              </Button>
            </Link>
          </motion.div>

          <div className="space-y-4">
            {liveTournaments.map((tournament, index) => (
              <motion.div
                key={tournament.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card hover={false} className="group">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 sm:p-6 gap-4">
                    {/* Tournament info */}
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 
                        flex items-center justify-center border border-gaming-border">
                        <Trophy className="w-6 h-6 text-neon-cyan" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-display font-semibold text-white">{tournament.name}</h3>
                          {tournament.status === 'live' ? (
                            <Badge variant="danger" size="sm" pulse>LIVE</Badge>
                          ) : (
                            <Badge variant="info" size="sm">OPEN</Badge>
                          )}
                        </div>
                        <p className="text-sm text-white/50">{tournament.game}</p>
                      </div>
                    </div>
                    
                    {/* Stats */}
                    <div className="flex items-center gap-6 sm:gap-8">
                      <div className="text-center">
                        <div className="text-lg font-display font-bold text-neon-green">
                          {formatCurrency(tournament.prizePool)}
                        </div>
                        <div className="text-xs text-white/50 uppercase">Prize Pool</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-display font-bold text-white">
                          {tournament.players}/{tournament.maxPlayers}
                        </div>
                        <div className="text-xs text-white/50 uppercase">Players</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-display font-bold text-neon-cyan">
                          {tournament.endsIn}
                        </div>
                        <div className="text-xs text-white/50 uppercase">Ends In</div>
                      </div>
                      <Button variant="primary" size="sm">
                        Join Now
                      </Button>
                    </div>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="h-1 bg-gaming-darker">
                    <div 
                      className="h-full bg-gradient-to-r from-neon-cyan to-neon-purple"
                      style={{ width: `${(tournament.players / tournament.maxPlayers) * 100}%` }}
                    />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Choose Deskillz?
            </h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              Built on blockchain technology for transparent, secure, and instant gaming experiences.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card variant="glow" className="text-center p-8 h-full">
                  <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 
                    flex items-center justify-center border border-neon-cyan/30">
                    <feature.icon className="w-8 h-8 text-neon-cyan" />
                  </div>
                  <h3 className="font-display text-xl font-semibold text-white mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-white/50 leading-relaxed">
                    {feature.description}
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <Card variant="glow" className="relative overflow-hidden">
              {/* Background effects */}
              <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/10 via-transparent to-neon-purple/10" />
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-neon-cyan/20 rounded-full blur-3xl" />
              
              <div className="relative p-8 sm:p-12 text-center">
                <h2 className="font-display text-3xl sm:text-4xl font-bold text-white mb-4">
                  Ready to Start Winning?
                </h2>
                <p className="text-white/60 mb-8 max-w-lg mx-auto">
                  Connect your wallet and join the competition. Your next victory is just a click away.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button
                    variant="primary"
                    size="lg"
                    leftIcon={<Wallet className="w-5 h-5" />}
                  >
                    Connect Wallet
                  </Button>
                  <Button variant="ghost" size="lg">
                    Learn More
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
