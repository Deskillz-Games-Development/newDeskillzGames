import { motion } from 'framer-motion'
import { Trophy } from 'lucide-react'

export default function TournamentsPage() {
  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-20"
        >
          <Trophy className="w-16 h-16 text-neon-cyan mx-auto mb-4" />
          <h1 className="font-display text-4xl font-bold text-white mb-4">
            Tournaments
          </h1>
          <p className="text-white/50">
            Browse and join active tournaments
          </p>
          <p className="text-white/30 mt-4">
            Full tournaments listing coming soon...
          </p>
        </motion.div>
      </div>
    </div>
  )
}
