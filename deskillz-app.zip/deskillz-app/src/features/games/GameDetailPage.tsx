import { useParams } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function GameDetailPage() {
  const { id } = useParams()
  
  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-20"
        >
          <h1 className="font-display text-4xl font-bold text-white mb-4">
            Game Detail
          </h1>
          <p className="text-white/50">
            Game ID: {id}
          </p>
          <p className="text-white/30 mt-4">
            Full game detail page coming soon...
          </p>
        </motion.div>
      </div>
    </div>
  )
}
