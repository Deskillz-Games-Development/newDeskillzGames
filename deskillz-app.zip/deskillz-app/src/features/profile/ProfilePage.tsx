import { motion } from 'framer-motion'
import { User } from 'lucide-react'

export default function ProfilePage() {
  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-20"
        >
          <User className="w-16 h-16 text-neon-cyan mx-auto mb-4" />
          <h1 className="font-display text-4xl font-bold text-white mb-4">
            Player Profile
          </h1>
          <p className="text-white/50">
            View your stats, history, and achievements
          </p>
          <p className="text-white/30 mt-4">
            Full profile page coming soon...
          </p>
        </motion.div>
      </div>
    </div>
  )
}
